# Python doesn't have a syntax check, so this should fail at runtime
# with a RUN-ERROR.
#
# @EXPECTED_RESULTS@: RUN-ERROR

This is not correct Python syntax and will give errors!
