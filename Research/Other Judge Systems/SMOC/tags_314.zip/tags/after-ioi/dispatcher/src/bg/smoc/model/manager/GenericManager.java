package bg.smoc.model.manager;

public class GenericManager {
    
    ManagerMediator mediator;

    public void setMediator(ManagerMediator managerMediator) {
        mediator = managerMediator;
    }
}
