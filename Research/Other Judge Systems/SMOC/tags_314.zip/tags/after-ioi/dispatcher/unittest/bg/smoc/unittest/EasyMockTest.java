package bg.smoc.unittest;

import java.lang.annotation.Retention;

@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface EasyMockTest {

}
