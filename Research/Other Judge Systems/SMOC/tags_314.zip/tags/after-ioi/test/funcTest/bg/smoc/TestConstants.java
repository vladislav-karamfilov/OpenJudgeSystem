package bg.smoc;

public class TestConstants {

    public static final String BASE_URL = "http://localhost:8080/";

}
