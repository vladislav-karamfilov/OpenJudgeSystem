/*
TASK: aplusb
LANG: C
*/
#include<unistd.h>

int main()
{   sleep(14);
    return 0;
}
