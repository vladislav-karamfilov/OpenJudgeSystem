/*
TASK: mod
LANG: C
*/

int main()
{   int s,u,n,r;

    return 0;
}
