/*
 * Copyright 2002 HM Research, Ltd. All rights reserved.
 */

package kr.or.ioi2002.RMIServer.agent;

/**
 * 
 * @author Sunglim Lee
 * @version 1.00, 11/01/03
 */

public class AgentException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7505534144312561349L;

	public AgentException(String s) {
		super(s);
	}
}